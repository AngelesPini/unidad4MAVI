#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <vector>
#include <ctime>
#include <cstdlib>

using namespace sf;
/*clase enemigo*/
class Enemigo {
public:
    Enemigo(Texture& texture, float scale) {
        sprite.setTexture(texture);
        sprite.setScale(0.1f,0.1f);
        sprite.setPosition(rand() % 800, rand() % 800);
        tiempoVida = Clock();
        vivo = true;
    }

    void update() {
        if (vivo && tiempoVida.getElapsedTime().asSeconds() > 1.5) {
            vivo = false;
        }
    }

    Sprite sprite;
    bool vivo;
    Clock tiempoVida;
};

int main()
{
    srand(time(0));

    Texture texture;
    Texture cursorTexture;

    texture.loadFromFile("et.png");
    cursorTexture.loadFromFile("crosshair.png");

    RenderWindow App(VideoMode(1200, 800, 32), "Clickable");
    App.setMouseCursorVisible(false);

    Sprite cursorSprite(cursorTexture);
    cursorSprite.setScale(0.3f, 0.3f);
    cursorSprite.setOrigin(cursorSprite.getGlobalBounds().width / 2, cursorSprite.getGlobalBounds().height / 2);

    std::vector<Enemigo> enemigos;
    int enemigosDerrotados = 0;

    Clock enemigoAparecer;
    Time enemigoDesaparecer = seconds(1);

    while (App.isOpen()) {
        Event event;
        while (App.pollEvent(event)) {
            if (event.type == Event::Closed) {
                App.close();
            }
            else if (event.type == Event::MouseMoved) {
                cursorSprite.setPosition(event.mouseMove.x, event.mouseMove.y);
            }
            else if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
                for (Enemigo& enemigo : enemigos) {
                    if (enemigo.vivo && enemigo.sprite.getGlobalBounds().contains(cursorSprite.getPosition())) {
                        enemigo.vivo = false;
                        enemigosDerrotados++;
                    }
                }
            }
        }

 
        if (enemigoAparecer.getElapsedTime() >= enemigoDesaparecer) {
            enemigos.emplace_back(texture, 0.4f);
            enemigoAparecer.restart();
        }

        App.clear();


        for (Enemigo& enemigo : enemigos) {
            if (enemigo.vivo) {
                enemigo.update();
                App.draw(enemigo.sprite);
            }
        }

        App.draw(cursorSprite);
        App.display();

        if (enemigosDerrotados >= 5) {
            App.close();
        }
    }

    return 0;
}
/*me cost� un monton y tuve que buscar maneras y ayuda en todos lados, enviar el codigo a gpt para que lo vaya corrigiendo
Desafortunadamente el video adjuntado en el plan de trabajo no lo entend� bien y se escucha muy bajito
Estoy satisfecha con el resultado aunque me hubiese gustado lograrlo sola sin intervencion de gtp o google. 
Ser� cuestion de seguir practicando */