#include <SFML/Graphics.hpp>
using namespace sf;


int main()
{
    sf::RenderWindow App(sf::VideoMode(500, 500), "Adaptacion");
    sf::Vector2u maxWindowSize(1000, 1000);


    while (App.isOpen())
    {
        sf::Event event;
        while (App.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                App.close();

            else if (event.type == sf::Event::KeyPressed)
            {
                sf::Vector2u size = App.getSize();

                if (event.key.code == sf::Keyboard::Add && size.x < maxWindowSize.x && size.y < maxWindowSize.y)
                {
                    App.setSize(sf::Vector2u(size.x + 50, size.y + 50));
                }
                else if (event.key.code == sf::Keyboard::Subtract && size.x > 100 && size.y > 100)
                {
                    App.setSize(sf::Vector2u(size.x - 50, size.y - 50));
                }
            }
        }

        App.clear();


        App.display();
    }

    return 0;
}

