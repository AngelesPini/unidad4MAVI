
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Texture texture1;
Sprite sprite;
Sprite sprite1;



int main()
{

    sf::RenderWindow App(sf::VideoMode(1000, 800, 32), "Atrapado");

    texture.loadFromFile("rcircleg.png");
    texture1.loadFromFile("cuad_yellow.png");

    /*figuras*/
    sprite.setTexture(texture);
    sprite1.setTexture(texture1);

    /*Medidas*/
    float escalaX;
    float escalaY;
    float heightCuad;
    float widthCuad;
    float heightRef;
    float widthRef;

    /*Movimiento*/
    sf::Vector2f position(400, 300);
    bool isDragging = false;
    float movimiento = 10.0f;


    /*Escala del cuadrado amarillo con referencia del circulo verde*/
    heightCuad = (float)texture1.getSize().y;
    heightRef = (float)texture.getSize().y;
    widthCuad = (float)texture1.getSize().x;
    widthRef = (float)texture.getSize().x;
    escalaY = heightRef / heightCuad; escalaX = widthRef / widthCuad;

    sprite1.setScale(escalaX, escalaY);


    while (App.isOpen())
    {
        sf::Event event;

        while (App.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                App.close();
            else if (event.type == sf::Event::KeyPressed)
            {
                if(Keyboard::isKeyPressed(Keyboard::Left) == true && position.x > 0)
                {
                    isDragging = true;
                    position.x -= movimiento;

                    
                }else if (Keyboard::isKeyPressed(Keyboard::Right) == true && position.x + sprite.getGlobalBounds().width < App.getSize().x)
                {
                    isDragging = true;
                    position.x += movimiento;


                }
                else if (Keyboard::isKeyPressed(Keyboard::Down) == true && position.y + sprite.getGlobalBounds().height < App.getSize().y)
                {
                    isDragging = true;
                    position.y += movimiento; 


                }
                else if (Keyboard::isKeyPressed(Keyboard::Up) == true && position.y  > 0)
                {
                    isDragging = true;
                    position.y -= movimiento;


                }
                else if (Keyboard::isKeyPressed(Keyboard::Space) == true)
                {
                    sf::Vector2f originalScale(1.0f, 1.0f);//esto me lo dijo chat gpt porque no encontraba manera de modificar la escala al tama�o original
                    isDragging = true;
                    sprite1.setTexture(texture);
                    sprite1.setScale(originalScale);
                }
               
            }
        }

        /*al principio estaba setteando la posici�n arriba de todo y no entendia porque no funcionaba, 
        pero prestando atencion pude resolverlo (despues de hora y media jajajaaj)*/
        sprite1.setPosition(position);

        /*Limpiamos la ventana para que los sprites no se repliquen cada vez*/
        App.clear();

        /*Dibujo el sprite*/
        App.draw(sprite1);        

        /* Mostramos la ventana*/
        App.display();
    }

    return 0;



    /*Segun la documentacion que brinda google getGlobalBounds() sirve para capturar los extremos de la ventana SFML 
    Este cuadro delimitador incluye la posici�n, el tama�o y la escala de la figura en el espacio global de la ventana, lo que te permite 
    determinar su ubicaci�n y dimensiones en relaci�n con la ventana en la que se est� dibujando.*/
}