#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Texture texture1;
Sprite sprite;
Sprite sprite1;


int main()
{

    sf::RenderWindow App(sf::VideoMode(1000, 800, 32), "Splats");

    texture.loadFromFile("rcircle.png");
    texture1.loadFromFile("rcircleb.png");

    /*circuloRojo*/
    sprite.setTexture(texture);
    sprite1.setTexture(texture1);


    bool esVisible = false;
    bool esVisible1 = false;

    while (App.isOpen())
    {
        sf::Event event;

        while (App.pollEvent(event)) 
        {
            if (event.type == sf::Event::Closed)
                App.close();
            else if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left)
            {
                int x = event.mouseButton.x;
                int y = event.mouseButton.y;
                sprite.setPosition(x, y);
                esVisible = true;
            }
            else if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Right)
            {
                int x = event.mouseButton.x;
                int y = event.mouseButton.y;
                sprite1.setPosition(x, y);
                esVisible1 = true;
            }
        }

        if (esVisible) {
            App.draw(sprite);

        }
        if (esVisible1) {
            App.draw(sprite1);
        }

        /*En este caso NO limpio la ventana con App.clear()*/
      

        /* Mostramos la ventana*/
        App.display();
    }

    return 0;
}