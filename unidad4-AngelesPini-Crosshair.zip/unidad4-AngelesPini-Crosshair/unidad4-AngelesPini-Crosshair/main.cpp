#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Sprite sprite;

int main()
{

    texture.loadFromFile("crosshair.png");


    /*circulo0*/
    sprite.setTexture(texture);


    sf::RenderWindow App(sf::VideoMode(800, 600, 32), "Crosshair");

    /*Para esta parte me ayud� con google y chat gpt*/

    sf::Vector2u windowSize = App.getSize();


    sf::Vector2u imageSize = texture.getSize();


    float xPos = (windowSize.x - imageSize.x) / 2;
    float yPos = (windowSize.y - imageSize.y) / 2;

    sprite.setPosition(xPos, yPos);

    float scaleFactor = 0.5;
    sprite.scale(scaleFactor, scaleFactor);

    while (App.isOpen())
    {


        /*Limpiamos la ventana*/
        App.clear();

        /* Dibujamos la escena*/
        App.draw(sprite);

        /* Mostramos la ventana*/
        App.display();
    }

    return 0;
}

/*No puedo lograr tomar como referencia el centro de la imagen para que lo ubique en el centro de la pantalla
no s� si est� bien logrado el ejercicio*/