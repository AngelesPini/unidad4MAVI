#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

/*Texturas*/
Texture texture;
Sprite sprite;
/*Sprite sprite1;
Sprite sprite2;
Sprite sprite3;*/
int main()
{

    sf::RenderWindow App(sf::VideoMode(1000, 800, 32), "Drag - Puntos rojos");
    std::vector<sf::Sprite> sprites;

    texture.loadFromFile("rcircle.png");

    for (int i = 0; i < 4; ++i)
    {
        sf::Sprite sprite(texture);
        sprite.setPosition(i * 200, i % 2 == 0 ? 0 : 400);
        sprites.push_back(sprite);
    }

    sf::Vector2f offset;
    bool isDragging = false;

    /*circulo0*/
    sprite.setTexture(texture);

    /*circulo1
    sprite1.setTexture(texture);
    sprite1.setPosition(800, 0);

    /*circulo2
    sprite2.setTexture(texture);
    sprite2.setPosition(0, 600);

    /*circulo3
    sprite3.setTexture(texture);
    sprite3.setPosition(800, 600);*/

    while (App.isOpen())
    {
        sf::Event event;

        while (App.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                App.close();
            else if (event.type == sf::Event::MouseButtonPressed)
            {
                if (event.mouseButton.button == sf::Mouse::Left)
                {
                    for (sf::Sprite& sprite : sprites)
                    {
                        if(sprite.getGlobalBounds().contains(event.mouseButton.x, event.mouseButton.y)) 
                        {
                            isDragging = true;
                            offset = sprite.getPosition() - sf::Vector2f(event.mouseButton.x, event.mouseButton.y);
                        }
                    
                    }
                    

                }
            }
            else if (event.type == sf::Event::MouseButtonReleased)
            {
                if (event.mouseButton.button == sf::Mouse::Left)
                {
                    isDragging = false;
                }
            }
        }
        if (isDragging)
        {
            sf::Vector2i mousePosition = sf::Mouse::getPosition(App);
            for (sf::Sprite& sprite : sprites)
            {
                if (sprite.getGlobalBounds().contains(static_cast<sf::Vector2f>(mousePosition)))
                {
                    sprite.setPosition(static_cast<sf::Vector2f>(mousePosition) + offset);
                }
            }
        }

        /*Limpiamos la ventana*/
        App.clear();

        /*Dibujamos la escena*/
        for (const sf::Sprite& sprite : sprites)
        {
            App.draw(sprite);
        }

        /* Mostramos la ventana*/
        App.display();
    }

    return 0;
}


/*tuve que recurrir mucho a google y chat gpt para tratar de optimizar el codigo capturando los circulos en un conjunto
para no repetir errores de entregas anteriores. 
El unico problema que noto como tal, es que al superponer los ciruclos, estos se agrupan en un solo. Como si se "fusionaran"*/